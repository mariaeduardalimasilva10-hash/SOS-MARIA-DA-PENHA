
class Conta:

    def __init__(self,id,email,senha,dataCadastro):
        self.id = id
        self.email = email
        self.senha = senha
        self.dataCadastro = dataCadastro

    def autenticar(self):
        return True

    def alterarSenha(self,novaSenha):
        self.senha = novaSenha

    def encerrarSessao(self):
        print("Sessao encerrada")

#=============================================================================================
=============================================================================================#

class Vitima:

    def __init__(self,id,nome,cpf,telefone,senha):
        self.id = id
        self.nome = nome
        self.cpf = cpf
        self.telefone = telefone
        self.senha = senha

        #Relacionamento 1 para 1 entre Vitima e conta
        self.conta = None

        #Relacionamento 1 para0..* entre Vitima e Ocorrencias = []

        #Relacionamento 1 para 0..* entre Vitima e MedidaProtetiva
        self.medidasProtetivas = []
 
        #Relacionamento 1 para 0..* entre Vitima e BotaoPanico
        self.botoesPanico = []

    def cadastrar(self):
        print("Vitima cadastrada")

    def fazerLogin(self):
        return True

    def registrarOcorrencia(self,ocorrencia):
 self.ocorrencias.append(ocorrencia)    

    def pedirMedidaProtetiva(self,medidaProtetiva):

    def acionarBotaoPanico(self,botaoPanico):

 self.botoesPanico.append(botaoPanico)

#==========================================================================================
==========================================================================================#

class Administrador:

    def __init__(self,id,nome,email,senha):
        self.id = id
        self.nome = nome
        self.email = email
        self.senha = senha

        #Relacionamento do Administrador com o BotaoPanico
        self.botoesPanico = []

    def atualizarInformacoes(self):
        print("Informacoes atualizadas")

    def receberPedidoMedida(self,medidaProtetiva):
        print("Pedido de medida protetiva recebido")

    def acompanharSituacaoRisco(self,situacaoRisco):
        print("Situacao de risco acompanhada")


#=========================================================================================
=========================================================================================#

class Ocorrencia:

    def __init__(self,id,descricao,data,local,status):
        self.id = id
        self.descricao = descricao
        self.data = data
        self.local = local
        self.status = status

    def registrar(self):
        print("Ocorrencia registrada")
    
    def atualizarStatus(self):
        print("Status da ocorrencia atualizado")

    def consultar(self):
        return self

#======================================================================================
======================================================================================#

class MedidaProtetiva:

    def __init__(self, id, tipo, dataSolicitacao, dataValidade, status):
        self.id = id
        self.tipo = tipo
        self.dataSolicitacao = dataSolicitacao
        self.dataValidade = dataValidade
        self.status = status

        def solicitar(self):
             print("Medida protetiva solicitada")

        def consultarStatus(self):
            return self.status

        def atualizarStatus(self):
             print("Status da medida protetiva atualizado")
        

#========================================================================================
========================================================================================#

class BotaoPanico:

    def __init__(self, id, status, dataHoraAcionamento):
        self.id = id
        self.status = status
        self.dataHoraAcionamento = dataHoraAcionamento

        # Relacionamento 1 para 1 entre BotaoPanico e Alerta
        self.alerta = None

    def acionar(self):
        self.status = "Acionado"
        print("Botao de panico acionado")

    def cancelar(self):
        self.status = "Cancelado"

    def enviarAlerta(self):
        print("Alerta enviado")

#=========================================================================================
=========================================================================================#

class Alerta:

    def __init__(self, id, tipo, dataHora, mensagem, status):
        self.id = id
        self.tipo = tipo
        self.dataHora = dataHora
        self.mensagem = mensagem
        self.status = status

        # Relacionamento 1 para 0..1 entre Alerta e Localizacao
        self.localizacao = None

        # Relacionamento 1 para 0..* entre Alerta e Gravacao
        self.gravacoes = []

    def enviar(self):
        print("Alerta enviado")

    def cancelar(self):
        self.status = "Cancelado"

    def consultarStatus(self):
        return self.status

#=====================================================================================
=====================================================================================#
class Localizacao:

    def __init__(self, latitude, longitude, dataHora):
        self.latitude = latitude
        self.longitude = longitude
        self.dataHora = dataHora

    def obterLocalizacao(self):
        return self.latitude, self.longitude

    def atualizarLocalizacao(self):
        print("Localizacao atualizada")

    def compartilhar(self):
        print("Localizacao compartilhada")

#=====================================================================================
=====================================================================================#

class SituacaoRisco:

    def __init__(self, id, tipo, nivel, dataHora, status):
        self.id = id
        self.tipo = tipo
        self.nivel = nivel
        self.dataHora = dataHora
        self.status = status

        # Relacionamento 1 para 0..* entre SituacaoRisco e Gravacao
        self.gravacoes = []

    def detectar(self):
        print("Situacao de risco detectada")

    def classificar(self):
        print("Situacao de risco classificada")

    def gerarAlerta(self):
        print("Alerta gerado.")

#==========================================================================================
==========================================================================================#

class Gravacao:

    def __init__(self, id, tipo, arquivo, dataHoraInicio, duracao):
        self.id = id
        self.tipo = tipo
        self.arquivo = arquivo
        self.dataHoraInicio = dataHoraInicio
        self.duracao = duracao

    def iniciar(self):
        print("Gravacao iniciada")

    def finalizar(self):
        print("Gravacao finalizada")

    def armazenar(self):
        print("Gravacao armazenada")

#=====================================================================================
=====================================================================================#

# Vitima 1 ----- 1 Conta
vitima = Vitima(1, "Maria", "000.000.000-00", "99999-9999", "1234")
conta = Conta(1, "maria@email.com", "1234", datetime.now())

vitima.conta = conta


# Vitima 1 ----- 0..* Ocorrencia
ocorrencia = Ocorrencia(
    1,
    "Ameaça",
    datetime.now(),
    "Porto Velho",
    "Pendente"
)

vitima.ocorrencias.append(ocorrencia)


# Vitima 1 ----- 0..* MedidaProtetiva
medidaProtetiva = MedidaProtetiva(
    1,
    "Medida de urgência",
    datetime.now(),
    datetime.now(),
    "Pendente"
)

vitima.medidasProtetivas.append(medidaProtetiva)


# Vitima 1 ----- 0..* BotaoPanico
botaoPanico = BotaoPanico(
    1,
    "Disponível",
    datetime.now()
)

vitima.botoesPanico.append(botaoPanico)


# BotaoPanico 1 ----- 1 Alerta
alerta = Alerta(
    1,
    "Emergência",
    datetime.now(),
    "Botão de pânico acionado",
    "Pendente"
)

botaoPanico.alerta = alerta


# Alerta 1 ----- 0..1 Localizacao
localizacao = Localizacao(
    -8.7619,
    -63.9039,
    datetime.now()
)

alerta.localizacao = localizacao


# Alerta 1 ----- 0..* Gravacao
gravacao = Gravacao(
    1,
    "Áudio",
    "gravacao.mp3",
    datetime.now(),
    30.0
)

alerta.gravacoes.append(gravacao)


# SituacaoRisco 1 ----- 0..* Gravacao
situacaoRisco = SituacaoRisco(
    1,
    "Ameaça",
    "Alto",
    datetime.now(),
    "Detectada"
)

situacaoRisco.gravacoes.append(gravacao)


# Administrador ----- BotaoPanico
administrador = Administrador(
    1,
    "Administrador",
    "admin@email.com",
    "1234"
)

administrador.botoesPanico.append(botaoPanico)




